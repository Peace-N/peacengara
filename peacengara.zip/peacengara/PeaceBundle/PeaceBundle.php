<?php

namespace peacengara\PeaceBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PeaceBundle extends Bundle
{
}
