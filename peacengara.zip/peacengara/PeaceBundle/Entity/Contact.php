<?php

/**
 * Created by PhpStorm.
 * User: Peace Ngara
 * Date: 23/06/2017
 * Time: 00:45
 */
namespace peacengara\PeaceBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Routing\Tests\Fixtures\AnnotatedClasses;

/**
 * @ORM\Entity
 * @ORM\Table(name="contacts")
 */
class Contact
{
    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
    /**
     * @ORM\Column(type="string", length=100)
     */
    private $firstName;
    /**
     * @ORM\Column(type="string", length=100)
     */
    private $lastName;
    /**
     * @ORM\Column(type="integer")
     */
    private $contactNumber;
    /**
     * @ORM\Column(type="string", length=100)
     */
    private $userEmail;
    /**
     * @ORM\Column(type="string", length=100)
     */
    private $adminEmail;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set firstName
     *
     * @param string $firstName
     *
     * @return Contact
     */
    public function setFirstName($firstName)
    {
        $this->firstName = $firstName;

        return $this;
    }

    /**
     * Get firstName
     *
     * @return string
     */
    public function getFirstName()
    {
        return $this->firstName;
    }

    /**
     * Set lastName
     *
     * @param string $lastName
     *
     * @return Contact
     */
    public function setLastName($lastName)
    {
        $this->lastName = $lastName;

        return $this;
    }

    /**
     * Get lastName
     *
     * @return string
     */
    public function getLastName()
    {
        return $this->lastName;
    }

    /**
     * Set contactNumber
     *
     * @param integer $contactNumber
     *
     * @return Contact
     */
    public function setContactNumber($contactNumber)
    {
        $this->contactNumber = $contactNumber;

        return $this;
    }

    /**
     * Get contactNumber
     *
     * @return integer
     */
    public function getContactNumber()
    {
        return $this->contactNumber;
    }

    /**
     * Set userEmail
     *
     * @param string $userEmail
     *
     * @return Contact
     */
    public function setUserEmail($userEmail)
    {
        $this->userEmail = $userEmail;

        return $this;
    }

    /**
     * Get userEmail
     *
     * @return string
     */
    public function getUserEmail()
    {
        return $this->userEmail;
    }

    /**
     * Set adminEmail
     *
     * @param string $adminEmail
     *
     * @return Contact
     */
    public function setAdminEmail($adminEmail)
    {
        $this->adminEmail = $adminEmail;

        return $this;
    }

    /**
     * Get adminEmail
     *
     * @return string
     */
    public function getAdminEmail()
    {
        return $this->adminEmail;
    }
}
