<?php
/**
 * Created by PhpStorm.
 * User: Peace Ngara
 * Date: 23/06/2017
 * Time: 00:14
 */

namespace peacengara\PeaceBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use peacengara\PeaceBundle\Entity\Contact;
use peacengara\PeaceBundle\ContactType;
use Symfony\Component\HttpFoundation\Response;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Common\Persistence\ManagerRegistry;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpFoundation\Session\Storage\SessionStorageInterface;

class ContactController extends Controller {

    public function indexAction() {
        return$this->render('PeaceBundle:Contact:contactForm.html.twig');
    }

    public function saveAction(Request $request) {
        $contact = new Contact();
        $contact->setAdminEmail('dev@webhoop.co.za');
        $form = $this->createForm(ContactType::class, $contact);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid() && $this->captchaverify($request->get('g-recaptcha-response'))) {

            $em = $this->getDoctrine()->getManager();
            $em->persist($contact);
            $em->flush();
            $this->sendMail('Contact Request Saved', $contact, $contact->getUserEmail());
            $this->sendMail('Contact Request Saved', $contact, $contact->getAdminEmail());
            $this->addFlash('success', 'Your contact request has been saved');
            return $this->redirectToRoute('peace_homepage');
        }

        # check if captcha response isn't get throw a message g-recaptcha-response
        if($form->isSubmitted() &&  $form->isValid() && !$this->captchaverify($request->get('g-recaptcha-response'))){

            $this->addFlash(
                'error',
                'Captcha Require'
            );
        }

        return $this->render(
            'PeaceBundle:Contact:contact.html.twig',
            array('form' => $form->createView())
        );

    }

    # get success response from recaptcha and return it to controller
    function captchaverify($recaptcha){
        $secret = '6LcAnCYUAAAAAAQRYW6E_6gPuW7P-z2rn40z7qWc';
        $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$recaptcha);
        $responseData = json_decode($verifyResponse);
        return $responseData->success;
    }

    public function sendMail($subject, Contact $contact, $sendEmailTo) {
        $message = \Swift_Message::newInstance()
            ->setSubject($subject)
            ->setFrom($contact->getAdminEmail())
            ->setTo($sendEmailTo)
            ->setBody(
                'Hello ' . $contact->getFirstName() . 'Thank you for your email'
            );
        $this->get('mailer')->send($message);
    }

    public function viewAction() {
        $em = $this->getDoctrine()->getManager();
        $contacts = $em->getRepository('peacengara/PeaceBundle:Contact')
            ->findAll();
        return $this->render('PeaceBundle:Contact:contacts.html.twig', [
            'contacts' => $contacts
        ]);

    }

}